// Sample product data (replace with your actual data source)
const products = [
    { id: 'product1', name: 'Luxury Chair 1', price: 3500, description: 'A luxurious chair with elegant design and premium materials.', images: ['images/luxury_1.jpg'] },
    { id: 'product2', name: 'Luxury Chair 2', price: 4000, description: 'A luxurious chair with elegant design and premium materials.', images: ['images/luxury_2.jpg'] },
    { id: 'product3', name: 'Office Chair 1', price: 4200, description: 'An ergonomic office chair for comfort during long work hours.', images: ['images/office_1.jpg'] },
    { id: 'product4', name: 'Office Chair 2', price: 4800, description: 'A stylish office chair with adjustable features.', images: ['images/office_2.jpg'] },
    { id: 'product5', name: 'Dining Chair 1', price: 1800, description: 'A comfortable dining chair with a modern design.', images: ['images/dining_1.jpg'] },
    { id: 'product6', name: 'Dining Chair 2', price: 2200, description: 'A classic dining chair with a wooden frame.', images: ['images/dining_2.jpg'] },
    { id: 'product7', name: 'Recliner Chair 1', price: 7500, description: 'A recliner chair with plush cushioning for ultimate relaxation.', images: ['images/recliner_1.jpg'] },
    { id: 'product8', name: 'Recliner Chair 2', price: 8500, description: 'A premium recliner chair with adjustable settings.', images: ['images/recliner_2.jpg'] }
];

let cart = [];
let total = 0;

function showProductDetails(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        document.getElementById('product-image').src = product.images[0];
        document.getElementById('product-name').innerText = product.name;
        document.getElementById('product-price').innerText = `Price: ₹${product.price}`;
        document.getElementById('product-description').innerText = product.description;
        document.getElementById('product-details').classList.remove('hidden');
    }
}

function toggleCart() {
    const cartDetails = document.getElementById('cart-details');
    cartDetails.style.display = cartDetails.style.display === 'block' ? 'none' : 'block';
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        cart.push(product);
        total += product.price;
        updateCart();
    }
}

function updateCart() {
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';
    cart.forEach(item => {
        const li = document.createElement('li');
        li.innerText = `${item.name} - ₹${item.price}`;
        cartItems.appendChild(li);
    });
    document.getElementById('cart-total').innerText = total;
    document.getElementById('cart-count').innerText = cart.length;
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.category h3').forEach(header => {
        header.addEventListener('click', () => {
            const content = header.nextElementSibling;
            if (content.style.display === 'block') {
                content.style.display = 'none';
                header.querySelector('.toggle-icon').innerText = '▼';
            } else {
                content.style.display = 'block';
                header.querySelector('.toggle-icon').innerText = '▲';
            }
        });
    });

    document.querySelectorAll('.product a').forEach(link => {
        link.addEventListener('click', () => {
            const productId = link.getAttribute('onclick').match(/'([^']+)'/)[1];
            showProductDetails(productId);
        });
    });

    // Cart icon click event
    document.getElementById('cart-icon').addEventListener('click', toggleCart);
});
